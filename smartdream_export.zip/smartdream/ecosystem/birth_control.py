import random

class BirthControl:
    """
    Manages symbolic agent population limits, lifecycle policies,
    and reproduction logic within an adaptive system.
    """
    def __init__(self, max_population=100):
        self.max_population = max_population
        self.population = []

    def register(self, agent):
        """
        Add a new agent to the population, with overflow handling.
        """
        self.population.append(agent)
        if len(self.population) > self.max_population:
            self.cull_least_fit()

    def cull_least_fit(self):
        """
        Remove the least fit agent to maintain symbolic balance.
        """
        self.population.sort(key=lambda a: a.compute_fitness())
        removed = self.population.pop(0)
        removed.memory.record_event("culled", metadata={"reason": "low_fitness"})

    def eligible_for_birth(self, agent):
        """
        Check whether an agent is allowed to generate offspring.
        Could be modified to check symbolic clarity, contribution, etc.
        """
        return agent.compute_fitness() > 10 and len(self.population) < self.max_population

    def population_summary(self):
        return {
            "count": len(self.population),
            "max": self.max_population,
            "avg_fitness": round(sum(a.compute_fitness() for a in self.population) / max(1, len(self.population)), 2)
        }
