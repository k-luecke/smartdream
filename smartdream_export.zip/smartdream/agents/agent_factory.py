from agents.agent import Agent
from agents.genome import Genome
from agents.species import assign_species_traits

class AgentFactory:
    def __init__(self):
        self.registry = []

    def create_agent(self, name=None, species_name=None):
        genome = Genome.random()
        if species_name:
            genome.y["species"] = species_name
        agent = Agent(name=name, genome=genome)
        self.registry.append(agent)
        return agent

    def create_population(self, size=10, species_distribution=None):
        population = []
        if species_distribution:
            species_list = list(species_distribution.items())
            species_pool = [species for species, count in species_list for _ in range(count)]
            for _ in range(size):
                chosen_species = species_pool.pop() if species_pool else None
                agent = self.create_agent(species_name=chosen_species)
                population.append(agent)
        else:
            for _ in range(size):
                agent = self.create_agent()
                population.append(agent)
        return population

    def get_all_agents(self):
        return self.registry
