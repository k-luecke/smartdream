import random

# This generation cycle defines symbolic transformations for agents during drift/ritual
# Agents may symbolically evolve through these stages across time or via environmental triggers

generation_cycle = {
    "Wanderer": "Initiate",
    "Initiate": "Seeker",
    "Seeker": "Transmitter",
    "Transmitter": "Anchor",
    "Anchor": "Dissolver",
    "Dissolver": "Wanderer",  # cycle completes
}

# Each species template could include unique trait presets
species_templates = {
    "Seraph": {
        "resonance_threshold": 0.03,
        "seer_threshold": 0.08,
        "confidence_modulation": 1.2,
        "entry_threshold": 0.7,
        "exit_threshold": 0.3
    },
    "Mycelid": {
        "resonance_threshold": 0.07,
        "seer_threshold": 0.02,
        "confidence_modulation": 0.9,
        "entry_threshold": 0.5,
        "exit_threshold": 0.2
    },
    "Chorite": {
        "resonance_threshold": 0.1,
        "seer_threshold": 0.04,
        "confidence_modulation": 1.0,
        "entry_threshold": 0.6,
        "exit_threshold": 0.4
    }
}

def assign_species_traits(agent):
    species_name = agent.genome.y.get("species")
    if species_name in species_templates:
        agent.expressed_traits.update(species_templates[species_name])
    else:
        agent.expressed_traits.update({
            "resonance_threshold": random.uniform(0.03, 0.1),
            "seer_threshold": random.uniform(0.01, 0.1),
            "confidence_modulation": random.uniform(0.8, 1.2),
            "entry_threshold": random.uniform(0.5, 0.8),
            "exit_threshold": random.uniform(0.2, 0.5)
        })
